# Mulesoft Tutorial Series
Sample mulesoft integration projects exploring different components and their configurattions. Suitable for the new learners
I tried to keep  these projects very simple and easy to learn. Used different components to make people understand of the usage and configurations.
Most of the applications can be imported directly to AnyPoint platform and executed. Few requires DB connectivity, third party applications.
